//10750142 - José Augusto Serra Mota
//10442579 - Pedro Henrique da Silva Araujo

public class ItemCompra {
    private Produto produto;
    private int quantidade;

    public ItemCompra(Produto produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public double obterSubtotal() {
        return quantidade * produto.getPreco();
    }

    public void mostrar() {
        String preco = String.format("R$ %.2f", produto.getPreco());
        String subtotal = String.format("R$ %.2f", obterSubtotal());

        System.out.printf("%-40s %12s %5d %12s%n",
                produto.getDescricao(), preco, quantidade, subtotal);
    }

    public Produto getProduto() {
        return produto;
    }

    public int getQuantidade() {
        return quantidade;
    }
}